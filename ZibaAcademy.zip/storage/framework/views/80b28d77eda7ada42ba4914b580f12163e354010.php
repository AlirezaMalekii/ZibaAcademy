<?php $__env->startSection('head'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('head'); ?>
    <link rel="stylesheet" href="/css/blog.css">
    <title>Document</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- start blog artice-->
    <article class="blog-page py-5">


        <!--index top-right gradient-->
        <div class="right-gradient">
            <img src="/images/right-gradient.png" alt="gradient">
        </div>


        <section class="container">
            <div class="blog-header text-center mb-5">
                <h1>
                    وبلاگ
                </h1>
            </div>
            <div class="row flex-row-reverse">
                <?php echo $__env->make('sections.blog.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="blog-page-left col-12 col-lg-9 mt-3 mt-lg-0" style="direction: rtl">
                    <!--blog item-->
                    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="index-blog-item">
                            <div class="index-blog-item-image">
                                <img src="<?php echo e($blog->files()->get()->first()->file['thumb']); ?>" alt="image">
                            </div>
                            <div class="index-blog-title" style="direction: ltr">
                                <div class="index-blog-title-title">
                                    <h6>
                                        <?php $__currentLoopData = $blog->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($category->title); ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </h6>
                                </div>
                                <div class="index-blog-title-items">
                                    <div class="index-blog-title-item">
                                        <p>
                                            <?php echo e($blog->viewCount); ?>

                                        </p>
                                        <img src="/images/Eye.png" alt="icon" width="20px" height="20px">
                                    </div>
                                    <div class="index-blog-title-item">
                                        <p>
                                            <?php echo e($blog->comments_count); ?>

                                        </p>
                                        <img src="/images/coment.png" alt="icon" width="20px" height="20px">
                                    </div>
                                </div>
                            </div>
                            <div class="index-blog-desc">
                                <h3>
                                    <?php echo e($blog->title); ?>

                                </h3>
                                <p>

                                    <?php echo e(Illuminate\Support\Str::limit($blog->body, 100)); ?>

                                </p>
                                <a style="direction: ltr">
                                    مشاهده
                                    <img src="/images/yellow-left-arrow.png" alt="icon">
                                </a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>


        <!-- index-page bottom-left gradient-->
        <div class="left-gradient">
            <img src="/images/left-gradient.png" alt="gradient">
        </div>
    </article>
    <!-- end blog article-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\dr.data\Desktop\ZibaAcademy\resources\views/layouts/blog/index.blade.php ENDPATH**/ ?>