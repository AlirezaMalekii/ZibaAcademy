<!DOCTYPE html>
<html lang="en">
<head>
    <?php $__env->startSection('head'); ?>
        <?php echo $__env->make('sections.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldSection(); ?>
</head>
<body>
<!-- start navbar section -->
<?php echo $__env->make('sections.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- end navbar section -->
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('content'); ?>

<!-- start footer -->
<?php echo $__env->make('sections.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- end footer -->
<?php echo $__env->yieldContent('script'); ?>
</body>
</html>
<?php /**PATH C:\Users\dr.data\Desktop\ZibaAcademy\resources\views/master.blade.php ENDPATH**/ ?>