<?php $__env->startSection('head'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('head'); ?>
    <link rel="stylesheet" href="/css/user-panel-dashbord.css">
    <script src="https://kit.fontawesome.com/dcc0def279.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="/css/orders.css">
    <title>Document</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <article class="user-dashbord-page py-5">
        <section class="container">
            <div class="row flex-column-reverse flex-lg-row">
                <div class="col-12 col-lg-8 d-flex flex-column-reverse flex-lg-column">
                    <?php if(!$orders): ?>
                        <div
                            class="card order-empty border-0 order-empty-card px-4 pb-1 mt-3 mb-3 mt-lg-0 d-flex flex-row-reverse align-items-center justify-content-between">
                            <div class="order-empty-title d-flex flex-row-reverse mt-3">
                                <img src="/images/danger.png" alt="icon" width="28px" height="28px">
                                <p class="mt-1">
                                    هیچ سفارشی هنوز ثبت نشده است.
                                </p>
                            </div>
                            <div class="order-empty-button">
                                <a href="<?php echo e(route('workshops')); ?>">
                                    مشاهده محصولات
                                </a>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="card border-0 order-table-card p-4 mt-3 mt-lg-0">
                            <table class="order-table">
                                <tr>
                                    <th class="text-center pb-2 pb-lg-3">
                                        سفارش
                                    </th>
                                    <th class="text-center pb-2 pb-lg-3">
                                        تاریخ
                                    </th>
                                    <th class="text-center pb-2 pb-lg-3">
                                        وضعیت
                                    </th>
                                    <th class="text-center pb-2 pb-lg-3">
                                        مجموع
                                    </th>
                                    <th class="text-center pb-2 pb-lg-3">
                                        عملیات ها
                                    </th>
                                </tr>
                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-center pt-3">
                                            #<?php echo e($order['id']); ?>

                                        </td>
                                        <td class="text-center pt-3">



                                            <?php echo e(jdate($order['created_at'])->format('%d %B %Y')); ?>

                                        </td>
                                        <td class="text-center pt-3">
                                            <?php switch($order['status']):
                                                case ('paid'): ?>
                                                    پرداخت شده
                                                    <?php break; ?>
                                                <?php case ('cancel'): ?>
                                                    کنسل شده
                                                    <?php break; ?>
                                                <?php default: ?>
                                                    در انتظار پرداخت
                                            <?php endswitch; ?>
                                        </td>
                                        <td class="text-center pt-3">
                                            <?php echo e($order['total_price']); ?> تومان برای <?php echo e($order['items_count']); ?> مورد
                                        </td>
                                        <td class="text-center pt-3">
                                            <div class="order-item-operation">
                                                <a href="<?php echo e(route('order-info',['order'=>$order['id']])); ?>" class="order-operation green mr-1">
                                                    نمایش
                                                </a>
                                                <?php if($order['status']!='paid'): ?>
                                                    <a href="<?php echo e(route('continue_order',['order'=>$order['id']])); ?>" class="order-operation lgreen mr-1">
                                                        پرداخت
                                                    </a>
                                                    <a href="#" class="order-operation red mr-1">
                                                        لغو
                                                    </a>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
                <?php echo $__env->make('sections.user-panel.sidebar',compact('user'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </section>
    </article>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\dr.data\Desktop\ZibaAcademy\resources\views/layouts/user-panel/orders.blade.php ENDPATH**/ ?>