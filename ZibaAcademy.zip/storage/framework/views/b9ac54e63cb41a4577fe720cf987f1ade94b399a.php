<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!--css files-->
<link rel="stylesheet" href="/css/globalstyle.css">
<link rel="stylesheet" href="/css/reset.css">
<!--bootstrap cdn-->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.3/dist/jquery.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<!--main.js-->
<script src="/js/main.js"></script>
<?php /**PATH C:\Users\dr.data\Desktop\ZibaAcademy\resources\views/sections/head.blade.php ENDPATH**/ ?>