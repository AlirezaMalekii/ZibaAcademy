<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body>
<form method="POST" action="<?php echo e(session()->get('phone') ? route('lwo') : route('make-otp')); ?>">
    <?php echo csrf_field(); ?>
    <div>
        <?php if($errors->any()): ?>
            <div class="bg-red-700">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
    </div>
    <div class="mt-4">
        <div class="mt-4">
            <label class="block" for="phone">phone<label>
                    <input type="text" placeholder="phone" name="phone"

                           class="w-full px-4 py-2 mt-2 border rounded-md focus:outline-none focus:ring-1 focus:ring-blue-600" value="<?php echo e(session()->get('phone')??''); ?>">
        </div>
        <div class="mt-4">
            <label class="block" for="phone">code<label>
                    <input type="text" placeholder="phone" name="code"
                           class="w-full px-4 py-2 mt-2 border rounded-md focus:outline-none focus:ring-1 focus:ring-blue-600">
        </div>
        
        
        
        
        

        <span class="text-xs text-red-400">Password must be same!</span>
        <div class="flex">
            <button class="w-full px-6 py-2 mt-4 text-white bg-blue-600 rounded-lg hover:bg-blue-900">Create
                Account
            </button>
        </div>
        <div class="mt-6 text-grey-dark">
            Already have an account?
            <a class="text-blue-600 hover:underline" href="#">
                Log in
            </a>
        </div>
    </div>
</form>

</body>
</html>
<?php /**PATH C:\Users\dr.data\Desktop\ZibaAcademy\resources\views/example/login-with-otp.blade.php ENDPATH**/ ?>