<?php $__env->startSection('head'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('head'); ?>
    <link rel="stylesheet" href="/css/workshops.css">
    <title>Document</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <article class="workshops-page" style="overflow: hidden">

        <!--workshops-page top-right gradient-->
        <div class="right-gradient">
            <img src="/images/right-gradient.png" alt="gradient">
        </div>

        <!-- start workshop items section-->
        <?php echo $__env->make('sections.workshop.workshops.ongoing-workshops',compact('ongoing_workshops'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- end workshop items section-->


        <!-- start workshop items section-->
        <?php echo $__env->make('sections.workshop.workshops.held-workshops',compact('held_workshops'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- end workshop items section-->


        <!--workshops-page bottom-left gradient-->
        <div class="left-gradient">
            <img src="/images/left-gradient.png" alt="gradient">
        </div>
    </article>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\dr.data\Desktop\ZibaAcademy\resources\views/layouts/workshop/workshops.blade.php ENDPATH**/ ?>