<?php $__env->startSection('head'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('head'); ?>
    <link rel="stylesheet" href="/css/inside-new-workshop.css">
    <title>Document</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <article class="new-workshop-page py-5" style="overflow: hidden">


        <!--workshops-page top-right gradient-->
        <div class="right-gradient">
            <img src="/images/right-gradient.png" alt="gradient">
        </div>


        <!-- start progress-bar section -->
        <section class="container prog-bar mb-5">
            <div class="prog-wrapper pt-4 pb-2 row d-flex justify-content-between">
                <div class="prog-item col-3">
                    <div class="prog-item-wrapper text-center">
                        <h3 class="p-3 prog-item-number d-flex align-items-center justify-content-center text-center">
                            1
                        </h3>
                        <p class="prog-item-desc mt-2">
                            جزییات ورکشاپ
                        </p>
                    </div>
                </div>
                <div class="prog-item col-3">
                    <div class="prog-item-wrapper text-center">
                        <h3 class="p-3 prog-item-number d-flex align-items-center justify-content-center text-center">
                            1
                        </h3>
                        <p class="prog-item-desc mt-2">
                            جزییات ورکشاپ
                        </p>
                    </div>
                </div>
                <div class="prog-item col-3">
                    <div class="prog-item-wrapper text-center">
                        <h3 class="p-3 prog-item-number d-flex align-items-center justify-content-center text-center">
                            1
                        </h3>
                        <p class="prog-item-desc mt-2">
                            جزییات ورکشاپ
                        </p>
                    </div>
                </div>
                <div class="prog-item col-3 active">
                    <div class="prog-item-wrapper text-center">
                        <h3 class="p-3 prog-item-number d-flex align-items-center justify-content-center text-center">
                            1
                        </h3>
                        <p class="prog-item-desc mt-2">
                            جزییات ورکشاپ
                        </p>
                    </div>
                </div>
            </div>
        </section>

        <!-- end progress-bar section -->


        <!-- start inside-new-workshop artice -->
        <section class="container inside-n-workshop">
            <div class="row d-flex flex-column-reverse flex-lg-row">
                <?php echo $__env->make('sections.workshop.inside-new-workshops.sidebar',compact('workshop_data'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="workshop-right col-12 col-lg-8">
                    <div class="new-workshop-right-hero text-right p-4">
                        <h1>
                            <?php echo e($workshop_data['title']); ?>

                        </h1>
                        <div class="new-workshop-right-hero-image mt-3">
                            <img src="<?php echo e($image[0]['file']['thumb']); ?>" alt="image">
                        </div>
                    </div>
                    <div class="new-workshop-right-desc text-right p-4 mt-4">
                        <h3>
                            معرفی ورکشاپ
                        </h3>
                        <div class="new-workshop-teaser mt-4">
                            <?php if($stream_video): ?>
                                <?php echo html_entity_decode($video_url); ?>

                            <?php else: ?>
                                <video controls>
                                    <source src="<?php echo e($video_url); ?>" type=video/mp4>
                                </video>
                            <?php endif; ?>
                        </div>
                        <h4 class="mt-5">
                            درباره ورکشاپ
                        </h4>
                        <p class="mt-3">
                          <?php echo e($workshop_data['body']); ?>

                        </p>
                    </div>
                </div>
            </div>
        </section>
        <!-- end inside-new-workshop artice -->


        <!--workshops-page bottom-left gradient-->
        <div class="left-gradient">
            <img src="/images/left-gradient.png" alt="gradient">
        </div>
    </article>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\dr.data\Desktop\ZibaAcademy\resources\views/layouts/workshop/inside-new-workshops.blade.php ENDPATH**/ ?>