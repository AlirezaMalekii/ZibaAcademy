<div class="new-workshop-left col-12 col-lg-4 d-flex flex-column-reverse flex-lg-column">
    <div class="new-workshop-left-sign text-right p-4 mt-3 mt-lg-0">
        <h4>
            قیمت ورکشاپ:
        </h4>
        <h5 class="desc-price text-center p-3 mt-3">

            <span dir="ltr"><?php echo e($workshop_data['price']); ?></span>
             تومان
        </h5>
        <?php if(auth()->guard()->guest()): ?>
        <p class="mt-5">
            لطفاً برای ثبت نام در ورکشاپ,ابتدا <a href="<?php echo e(route('login')); ?>">وارد سایت </a>شوید
        </p>
        <?php endif; ?>
        <a href="<?php echo e(route('workshop_register',['workshop'=>$workshop_data['slug']])); ?>" class="ex-bold-button">
            ثبت نام
        </a>
    </div>
    <div class="new-workshop-left-desc text-right p-4 mt-4">
        <h3>
            مشخصات ورکشاپ
        </h3>
        <div class="mt-4">
            <div class="new-workshop-left-desc-item d-flex flex-row-reverse">
                <img src="/images/user-tag.png" alt="icon" width="24px" height="24px">
                <p class="mr-2">
                    مدرس:خانم زیبا اسلامی
                </p>
            </div>
            <div class="new-workshop-left-desc-item d-flex flex-row-reverse">
                <img src="/images/Place-3.png" alt="icon" width="24px" height="24px">
                <p class="mr-2">
                    محل برگزاری :<?php echo e($workshop_data['city']); ?>

                </p>
            </div>
            <div class="new-workshop-left-desc-item d-flex flex-row-reverse">
                <img src="/images/Calender.png" alt="icon" width="24px" height="24px">
                <p class="mr-2">
                    زمان برگزاری:<?php echo e($workshop_data['date']); ?>

                </p>
            </div>
            <div class="new-workshop-left-desc-item d-flex flex-row-reverse">
                <img src="/images/clock.png" alt="icon" width="24px" height="24px">
                <p class="mr-2">
                    ساعت برگزاری:<?php echo e($workshop_data['hour']); ?>

                </p>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\dr.data\Desktop\ZibaAcademy\resources\views/sections/workshop/inside-new-workshops/sidebar.blade.php ENDPATH**/ ?>