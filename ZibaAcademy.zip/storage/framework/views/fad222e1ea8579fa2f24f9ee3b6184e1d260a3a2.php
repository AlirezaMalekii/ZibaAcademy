<section class="workshops-items py-5">
    <div class="container">
        <div class="workshops-header row d-flex justify-content-end mb-4">
            <h3 class="text-right">ورکشاپ های درحال برگزاری</h3>
        </div>
        <div class="row d-flex justify-content-between align-items-center" style="flex-direction: row-reverse;">
            <!--workshop item-->
            <?php $__currentLoopData = $ongoing_workshops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ongoing_workshop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-12 col-md-6 col-lg-3">
                <div class="card workshop-item px-2 pb-2 mb-5 mb-lg-0" style="background-image: url(<?php echo e($ongoing_workshop['files'][0]['file']['thumb']); ?>)">
                    <div class="card-body workshop-item-desc bg-white">
                        <h3 class="text-right mb-3">
                            <?php echo e($ongoing_workshop['title']); ?>

                        </h3>
                        <div class="workshop-item-desc-location d-flex justify-content-end">
                            <p class="text-right">
                                محل برگزاری: <?php echo e(\App\Models\City::find($ongoing_workshop['city_id'])->name); ?>

                            </p>
                            <img class="mt-1 ml-2" src="/images/location.png" alt="icon" width="14px" height="18px">
                        </div>
                        <div class="workshop-item-desc-location d-flex justify-content-end">
                            <p>
                                زمان برگزاری: <?php echo e(jdate($ongoing_workshop['event_time'])->format('Y/m/d')); ?>

                            </p>
                            <img class="mt-1 ml-2" src="/images/date.png" alt="icon" width="16px" height="18px">
                        </div>
                        <div class="workshop-item-button">
                            <a href="<?php echo e(route('choose-workshop',['workshop'=>$ongoing_workshop['slug']])); ?>" class="py-2">مشاهده جزییات بیشتر</a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php /**PATH C:\Users\dr.data\Desktop\ZibaAcademy\resources\views/sections/workshop/workshops/ongoing-workshops.blade.php ENDPATH**/ ?>