<?php $__env->startSection('head'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('head'); ?>
    <script src="https://kit.fontawesome.com/dcc0def279.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="/css/orders.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- start user-dashbord-page -->
    <article class="user-dashbord-page py-5">
        <section class="container">
            <div class="row flex-column-reverse flex-lg-row">
                <div class="col-12 col-lg-8 d-flex flex-column-reverse flex-lg-column">
                    <div class="card border-0 order-detail-card mt-3 mt-lg-0">
                        <div class="order-detail p-4">
                            <p class="order-detail-title text-right">
                                <?php if($order_data['status']=='paid'): ?>
                                    سفارش #<?php echo e($order_data['id']); ?> در تاریخ <?php echo e(jdate($order_data['created_at'])->format('%d %B %Y')); ?> ثبت شده است و در حال حاضر در
                                    وضعیت تکمیل شده
                                    می‌باشد.
                                <?php elseif($order_data['status']=='pending'): ?>
                                    سفارش #<?php echo e($order_data['id']); ?> در تاریخ <?php echo e(jdate($order_data['created_at'])->format('%d %B %Y')); ?> ثبت شده است و در حال حاضر در
                                    وضعیت آماده پرداخت
                                    می‌باشد.
                                <?php elseif($order_data['status']=='cancel'): ?>
                                    سفارش #<?php echo e($order_data['id']); ?> در تاریخ <?php echo e(jdate($order_data['created_at'])->format('%d %B %Y')); ?> ثبت شده است و در حال حاضر در
                                    وضعیت لغو شده
                                    می‌باشد.
                                <?php endif; ?>
                            </p>
                            <?php if($order_data['is_paid']): ?>
                                <div class="order-detail-desc text-right mt-4 pb-3">
                                    <p class="mb-1">
                                        <?php echo e(jdate($payment_date)->format('%A, %d %B %Y, H:i')); ?>


                                    </p>
                                    <p class="mb-1">
                                        پرداخت موفقیت آمیز بود .
                                    </p>
                                    <p class="mb-1">
                                        کد رهگیری : <?php echo e($code); ?>

                                    </p>
                                </div>
                            <?php endif; ?>
                            <?php $__currentLoopData = $order_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div
                                    class="order-detail-cancel-items d-flex flex-column flex-lg-row justify-content-between text-right align-items-center mt-4">
                                    <div class="order-detail-cancel-item-image mb-3 mb-lg-0">
                                        <img src="/images/order-cancel.png" alt="image">
                                    </div>
                                    <div
                                        class="order-detail-cancel-item-price d-flex flex-row flex-lg-column justify-content-between">
                                        <h5>
                                            محصول
                                        </h5>
                                        <p>
                                            <?php echo e($order_item->itemable()->get()->first()->title); ?>

                                        </p>
                                    </div>
                                    <div
                                        class="order-detail-cancel-item-price d-flex flex-row flex-lg-column justify-content-between">
                                        <h5>
                                            تعداد
                                        </h5>
                                        <p>
                                            <?php echo e($order_item->quantity); ?>

                                        </p>
                                    </div>
                                    <div
                                        class="order-detail-cancel-item-price d-flex flex-row flex-lg-column justify-content-between">
                                        <h5>
                                            قیمت واحد
                                        </h5>
                                        <p>
                                            <?php echo e(number_format($order_item->itemable()->get()->first()->price)); ?> تومان
                                        </p>
                                    </div>
                                    <div
                                        class="order-detail-cancel-item-price d-flex flex-row flex-lg-column justify-content-between">
                                        <h5>
                                            قیمت کل
                                        </h5>
                                        <p>
                                            <?php echo e(number_format($order_item->itemable()->get()->first()->price * $order_item->quantity)); ?>

                                            تومان
                                        </p>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
                <?php echo $__env->make('sections.user-panel.sidebar',compact('user'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </section>
    </article>
    <!-- end user-dashbord-page -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\dr.data\Desktop\ZibaAcademy\resources\views/layouts/user-panel/inside-orders.blade.php ENDPATH**/ ?>