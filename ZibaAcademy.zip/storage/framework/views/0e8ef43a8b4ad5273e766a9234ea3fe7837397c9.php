<section class="container prog-bar mb-5">
    <div class="prog-wrapper pt-4 pb-2 row d-flex justify-content-between">
        <div class="prog-item col-3">
            <div class="prog-item-wrapper text-center">
                <h3 class="p-3 prog-item-number d-flex align-items-center justify-content-center text-center">
                    1
                </h3>
                <p class="prog-item-desc mt-2">
                    جزییات ورکشاپ
                </p>
            </div>
        </div>
        <div class="prog-item col-3">
            <div class="prog-item-wrapper text-center">
                <h3 class="p-3 prog-item-number d-flex align-items-center justify-content-center text-center">
                    1
                </h3>
                <p class="prog-item-desc mt-2">
                    جزییات ورکشاپ
                </p>
            </div>
        </div>
        <div class="prog-item col-3">
            <div class="prog-item-wrapper text-center">
                <h3 class="p-3 prog-item-number d-flex align-items-center justify-content-center text-center">
                    1
                </h3>
                <p class="prog-item-desc mt-2">
                    جزییات ورکشاپ
                </p>
            </div>
        </div>
        <div class="prog-item col-3 active">
            <div class="prog-item-wrapper text-center">
                <h3 class="p-3 prog-item-number d-flex align-items-center justify-content-center text-center">
                    1
                </h3>
                <p class="prog-item-desc mt-2">
                    جزییات ورکشاپ
                </p>
            </div>
        </div>
    </div>
</section>
<?php /**PATH C:\Users\dr.data\Desktop\ZibaAcademy\resources\views/sections/workshop/progress-bar.blade.php ENDPATH**/ ?>