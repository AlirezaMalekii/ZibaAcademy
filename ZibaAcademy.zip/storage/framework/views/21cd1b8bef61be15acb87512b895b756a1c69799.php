<?php $__env->startSection('head'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('head'); ?>
    <!--css files-->
    <link rel="stylesheet" href="/css/sign-in.css">
    <!--font awesome cdn-->
    <script src="https://kit.fontawesome.com/dcc0def279.js" crossorigin="anonymous"></script>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js']); ?>
    <title>Document</title>
<?php $__env->stopSection(); ?>
<!-- start sigin-in page article-->
<?php $__env->startSection('content'); ?>
    <article class="sign-in-page py-5">
        <section class="container">
            <div class="col-12 col-lg-5 sign-in-bar-wrapper">
                <div class="card sign-in-bar p-2">
                    <div class="d-flex">
                        <div class="col-6 text-center sign-in-bar-item">
                            <a href="<?php echo e(route('register')); ?>" class="tex-center">
                                ثبت نام
                            </a>
                        </div>
                        <div class="col-6 text-center sign-in-bar-item active">
                            <a href="#" class="tex-center" style="cursor:default">
                                ورود به حساب کاربری
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-lg-6 sign-in-form-wrapper mt-4"
                 x-data="{ phone: false}" x-init="phone= <?php echo e(session()->get('phone') !== null); ?>">
                <div class="card sign-in-form p-5 text-right">
                    <h2 class="text-center">
                        ورود
                    </h2>
                    <form method="POST" action="<?php echo e(session()->get('phone') ? route('lwo') : route('make-otp')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group d-flex flex-column">
                            <label for="phone">تلفن همراه</label>
                            <input type="text" name="phone" id="phone" class="p-2"
                                   value="<?php echo e(session()->get('phone')??''); ?>" :readonly="phone">
                        </div>
                        <button class="sign-in-button mt-3" style="border: none; width: 100%; margin-top: 2rem !important;"
                                :type="!phone ? 'submit' : 'button'"
                                @click="!phone ? $refs.form.submit() : null">
                                ورود با کد پیامکی
                            </button>
                        <div class="code-input mt-4">
                            <input type="text" name="code" class="p-2" placeholder="کد ارسال شده را وارد کنید" :disabled="!phone">
                        </div>
                        <button class="sign-in-button mt-5" style="border: none; width: 100%; margin-top: 2rem !important;" type="button" @submit.prevent="!phone"
                                :type="phone ? 'submit' : 'button'"
                                @click="phone ? $refs.form.submit() : null">
                            ثبت کد پیامکی
                        </button>
                    </form>
                </div>
            </div>
        </section>
    </article>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\dr.data\Desktop\ZibaAcademy\resources\views/layouts/auth/login-with-otp.blade.php ENDPATH**/ ?>