<?php $__env->startSection('head'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('head'); ?>
    <link rel="stylesheet" href="/css/inside-workshop.css">
    <title>Document</title>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <article class="inside-workshop-page py-5">
        <!--workshops-page top-right gradient-->
        <div class="right-gradient">
            <img src="/images/right-gradient.png" alt="gradient">
        </div>


        <section class="container inside-workshop-desc p-5">
            <div class="inside-workshop-title row d-flex justify-content-end pb-2">
                <h1><?php echo e($workshop_data['title']); ?></h1>
            </div>
            <div class="workshop-desc-desc mt-3">
                <div class="row d-flex flex-row-reverse">
                    <div class="d-flex mr-3">
                        <p class="mr-2">محل برگزاری: <?php echo e($workshop_data['city']); ?></p>
                        <img src="/images/location.png" width="20px" height="20px">
                    </div>
                    <div class="d-flex mr-3">
                        <p class="mr-2">زمان برگزاری: <?php echo e($workshop_data['date']); ?></p>
                        <img src="/images/date.png" width="20px" height="20px">
                    </div>
                    <div class="d-flex mr-3">
                        <p class="mr-2">تعداد شرکت کنندگان:<?php echo e($workshop_data['capacity']); ?> نفر</p>
                        <img src="/images/people.png" width="20px" height="20px">
                    </div>
                </div>
            </div>
            <div class="workshop-desc-images mt-2">
                <div class="row d-flex" style="flex-direction: row-reverse">
                    <!--workshop-desc image item -->
                    <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-6 col-lg-3 mb-4">
                            <div class="card border-0">
                                <div class="card-body workshop-desc-image p-0">
                                    <img src="<?php echo e($gallery['file']['thumb']); ?>" alt="image">
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="workshop-teaser-header row d-flex justify-content-end mt-5">
                <h3>
                    تیزر ورکشاپ
                </h3>
            </div>
            
            
            <div class="workshop-teaser ml-auto mt-3">
                <?php if($stream_video): ?>
                    <?php echo html_entity_decode($video_url); ?>

                <?php else: ?>
                    <video controls>
                        <source src="<?php echo e($video_url); ?>" type=video/mp4>
                    </video>
                <?php endif; ?>
            </div>
            <div class="row about-workshop d-flex justify-content-end mt-5">
                <h3>درباره ورکشاپ</h3>
                <p class="text-right">
                    <?php echo e($workshop_data['body']); ?>

                </p>
            </div>
        </section>
        <!-- comments section -->
        <section class="container mt-5 workshop-inside-comment p-5">
            <div class="row workshop-comments-title d-flex justify-content-end mb-4">
                <h3>نظرات شرکت کنندگان</h3>
            </div>
            <ul class="comment-items" id="comment-items">
                <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="row mt-2 comment-item d-flex justify-content-between align-items-center">
                    <div class="comment-desc text-right" style="flex-basis: 80%">
                        <div class="comment-name d-flex align-items-center">
                            <div class="comment-name-image">
                                <img src="/images/comment-image.png" alt="image">
                            </div>
                            <div class="comment-name-name">
                                <h6><?php echo e($comment['name']); ?></h6>
                            </div>
                        </div>
                        <div class="comment-desc-desc mt-1">
                            <p>
                                <?php echo e($comment['comment']); ?>

                            </p>
                        </div>
                    </div>
                    <div class="comment-date">
                        <p>
                            <?php echo e(jdate($comment['created_at'])->format('%d %B %Y')); ?>

                        </p>
                    </div>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="row mt-2 comment-item d-flex justify-content-between align-items-center">
                        <div class="comment-desc text-right">
                            <div class="comment-name d-flex align-items-center">
                                <div class="comment-name-image">
                                    <img src="/images/comment-image.png" alt="image">
                                </div>
                                <div class="comment-name-name">
                                    <h6>محمد صادق زمانی</h6>
                                </div>
                            </div>
                            <div class="comment-desc-desc mt-1">
                                <p>
                                    لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ، و با استفاده از طراحان گرافیک است
                                </p>
                            </div>
                        </div>
                        <div class="comment-date">
                            <p>
                                25 فروردین 1401
                            </p>
                        </div>
                    </div>
                    <!-- comment item  -->
                    <div class="row mt-2 comment-item d-flex justify-content-between align-items-center">
                        <div class="comment-desc text-right">
                            <div class="comment-name d-flex align-items-center">
                                <div class="comment-name-image">
                                    <img src="/images/comment-image.png" alt="image">
                                </div>
                                <div class="comment-name-name">
                                    <h6>محمد صادق زمانی</h6>
                                </div>
                            </div>
                            <div class="comment-desc-desc mt-1">
                                <p>
                                    لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ، و با استفاده از طراحان گرافیک است
                                </p>
                            </div>
                        </div>
                        <div class="comment-date">
                            <p>
                                25 فروردین 1401
                            </p>
                        </div>
                    </div>
                    <!-- comment item  -->
                    <div class="row mt-2 comment-item d-flex justify-content-between align-items-center">
                        <div class="comment-desc text-right">
                            <div class="comment-name d-flex align-items-center">
                                <div class="comment-name-image">
                                    <img src="/images/comment-image.png" alt="image">
                                </div>
                                <div class="comment-name-name">
                                    <h6>محمد صادق زمانی</h6>
                                </div>
                            </div>
                            <div class="comment-desc-desc mt-1">
                                <p>
                                    لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ، و با استفاده از طراحان گرافیک است
                                </p>
                            </div>
                        </div>
                        <div class="comment-date">
                            <p>
                                25 فروردین 1401
                            </p>
                        </div>
                    </div>
            </ul>
            <div class="row mt-4 comments-show d-flex justify-content-center align-items-center">
                <button class="d-flex flex-row-reverse align-items-center" onclick="showcomments()">
                    دیدن نظرات بیشتر
                    <img src="/images/To-Down.png" alt="icon">
                </button>
            </div>
        </section>


        <!-- write comment section-->
        <form method="post" action="<?php echo e(route('workshop_create_comment',[$workshop_data['slug']])); ?>">
            <?php echo csrf_field(); ?>
            <section class="container write-comment pr-5 py-4 mt-5 d-flex flex-column align-items-end">

                <div class="row d-flex justify-content-end">
                    <h3 class="write-comment-title">
                        ثبت دیدگاه:
                    </h3>
                </div>
                <div class="row write-comment-area mt-3">
            <textarea class="pr-4 pt-4" name="comment" rows="5" id="write-comment"
                      placeholder="دیدگاه خود را وارد کنید"></textarea>
                </div>
                <div class="row mt-3">
                    <button type="submit" class="record-button">
                        ثبت
                    </button>
                </div>
            </section>
        </form>

        <!--workshops-page bottom-left gradient-->
        <div class="left-gradient">
            <img src="/images/left-gradient.png" alt="gradient">
        </div>
    </article>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\dr.data\Desktop\ZibaAcademy\resources\views/layouts/workshop/inside-workshop.blade.php ENDPATH**/ ?>