<article class="record py-3">
    <section class="record-wrapper d-flex row justify-content-center align-items-center container">
        <div class="record-item col-6 col-lg-3 d-flex justify-content-center align-items-center flex-column">
            <h6>+114</h6>
            <p>تعداد هنرجویان</p>
        </div>
        <div class="record-item col-6 col-lg-3 d-flex justify-content-center align-items-center flex-column">
            <h6>{{$number_of_workshops}}</h6>
            <p>ورکشاپ های برگزار شده</p>
        </div>
        <div class="record-item col-6 col-lg-3 d-flex justify-content-center align-items-center flex-column">
            <h6>+114</h6>
            <p>سابقه کار و تجربه</p>
        </div>
        <div class="record-item col-6 col-lg-3 d-flex justify-content-center align-items-center flex-column">
            <h6>+114</h6>
            <p>تعداد هنرجویان</p>
        </div>
    </section>
</article>
