<?php
return [
    'title'=>'وب سایت راکت',
    'description'=>'وبسایت آموزشی',
    'welcome'=>[
        'title'=>'به راکت خوش آمدید'
    ]
];
