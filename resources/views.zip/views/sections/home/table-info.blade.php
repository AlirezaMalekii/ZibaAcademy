<article class="record py-3">
    <section class="record-wrapper d-flex row justify-content-center align-items-center container">
        <div class="record-item col-6 col-lg-3 d-flex justify-content-center align-items-center flex-column">
            <h6 class="num" data-value="353">+000</h6>
            <p>تعداد هنرجویان</p>
        </div>
        <div class="record-item col-6 col-lg-3 d-flex justify-content-center align-items-center flex-column">
{{--            <h6>{{$number_of_workshops}}</h6>--}}
            <h6 class="num" data-value="14">00</h6>
            <p>ورکشاپ های برگزار شده</p>
        </div>
        <div class="record-item col-6 col-lg-3 d-flex justify-content-center align-items-center flex-column">
{{--            <h6>+114</h6>--}}
            <h6 class="num" data-value="10">+000</h6>
            <p>سابقه کار و تجربه</p>
        </div>
        <div class="record-item col-6 col-lg-3 d-flex justify-content-center align-items-center flex-column">
{{--            <h6>+114</h6>--}}
            <h6 class="num" data-value="5">+000</h6>
            <p>تعداد دوره</p>
        </div>
    </section>
</article>
